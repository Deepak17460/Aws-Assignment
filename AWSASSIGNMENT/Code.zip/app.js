// npm pacakages =================================
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import  dotenv from 'dotenv';
// npm pacakages =================================
dotenv.config();

// Routes =======================================
import HomeRoute from './routes/homeRoute.js';
import TeacherRoute from './routes/teacherRoute.js';
import StudentRoute from './routes/studentRoute.js';
// Routes =======================================


//set approot ===========================================
import path from "path";
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
global.appRoot = path.resolve(__dirname);

//========================================================

// MiddleWare =======================================
import teacherAuth from './controllers/middleware/teacherAuth.js';
import studentAuth from './controllers/middleware/studentAuth.js';
// MiddleWare =======================================

const PORT = process.env.PORT || 3000;
let app = express();

app.use(express.json({ limit: "10mb", extended: true }));
app.use(express.urlencoded({ limit: "10mb", extended: true }));
app.use(bodyParser.json());
app.use(cors());

app.use(express.static('public')); 

app.use('/api',HomeRoute);
app.use('/api/teacher',teacherAuth ,TeacherRoute);
app.use('/api/student', studentAuth,StudentRoute);

app.get('*',async (req,res) =>{
    res.sendFile(path.join(__dirname,'/public/index.html'));
  });


app.listen(PORT,() => {
    console.log("Running at port:: "+PORT);
});